wifi.setmode(wifi.STATION)
wifi.sta.config("futurehack","NOT-DISCLOSED");
